package com.nettrack.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("map", "Map", Icons.Filled.Map),
    Tab("test", "Test", Icons.Filled.Speed),
    Tab("compare", "Compare", Icons.Filled.BarChart),
    Tab("history", "History", Icons.Filled.History),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetTrackApp() {
    val system = isSystemInDarkTheme()
    var darkPref by rememberSaveable { mutableStateOf<Boolean?>(null) } // null = follow system
    val dark = darkPref ?: system
    val vm: NetViewModel = viewModel()

    NetTrackTheme(dark) {
        val nav = rememberNavController()
        val route = nav.currentBackStackEntryAsState().value?.destination?.route
        val showChrome = route != null && route != "splash"

        Scaffold(
            topBar = {
                if (showChrome) TopAppBar(
                    title = {
                        Text(
                            when (route) {
                                "settings" -> "Profile & Settings"
                                else -> Tabs.firstOrNull { it.route == route }?.label ?: "NetTrack"
                            }
                        )
                    },
                    actions = {
                        if (route != "settings") IconButton(onClick = { nav.navigate("settings") }) {
                            Icon(Icons.Filled.Settings, "Settings")
                        }
                    }
                )
            },
            bottomBar = {
                if (showChrome) NavigationBar {
                    Tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { pad ->
            NavHost(nav, startDestination = "splash", modifier = Modifier.padding(pad)) {
                composable("splash") {
                    LaunchedEffect(Unit) {
                        delay(1500)
                        nav.navigate("home") { popUpTo("splash") { inclusive = true } }
                    }
                    SplashScreen()
                }
                composable("home") { HomeScreen(vm, onRunTest = { nav.navigate("test") }) }
                composable("map") { MapScreen(vm) }
                composable("test") { SpeedTestScreen(vm) }
                composable("compare") { CompareScreen(vm) }
                composable("history") { HistoryScreen(vm) }
                composable("settings") { SettingsScreen(vm, dark) { darkPref = it } }
            }
        }
    }
}

@Composable
fun SplashScreen() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.NetworkCheck, null, Modifier.size(96.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text("NetTrack", fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Text(
            "Find Better Network. Experience Faster Internet.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
    }
}
