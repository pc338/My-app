package com.nettrack.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.floor
import kotlin.math.roundToLong

/** Fill these two values from your Firebase project (Project settings > General). */
object Config {
    const val PROJECT_ID = "nettrack-7c15c"
    const val API_KEY = "AIzaSyBuYVQ1AK_Av9srF8_70en-4UXhdO4Rmfg"
    val enabled get() = PROJECT_ID.isNotBlank() && API_KEY.isNotBlank()
}

data class CommunityPoint(
    val operator: String, val connection: String,
    val download: Double, val upload: Double, val ping: Double,
    val lat: Double, val lon: Double, val time: Long
)

/** Talks to Firestore through its REST API. Data is anonymous: no user id, location rounded to ~100 m. */
object Cloud {
    private const val CELL = 0.05 // ~5 km grid used to look up nearby tests
    private fun cell(lat: Double, lon: Double) = "${floor(lat / CELL).toInt()}_${floor(lon / CELL).toInt()}"
    private fun round3(v: Double) = (v * 1000).roundToLong() / 1000.0
    private fun base() = "https://firestore.googleapis.com/v1/projects/${Config.PROJECT_ID}/databases/(default)/documents"

    private fun str(v: String) = JSONObject().put("stringValue", v)
    private fun dbl(v: Double) = JSONObject().put("doubleValue", v)

    private fun post(url: String, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 10000; c.readTimeout = 15000
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally { c.disconnect() }
    }

    /** Shares one cellular test. Wi-Fi tests and unknown operators are never uploaded. */
    suspend fun upload(r: TestResult, lat: Double, lon: Double) = withContext(Dispatchers.IO) {
        if (!Config.enabled || Operators.none { it.name == r.operator }) return@withContext
        val la = round3(lat); val lo = round3(lon)
        val fields = JSONObject()
            .put("operator", str(r.operator)).put("connection", str(r.connection))
            .put("down", dbl(r.download)).put("up", dbl(r.upload)).put("ping", dbl(r.pingMs))
            .put("lat", dbl(la)).put("lon", dbl(lo))
            .put("time", JSONObject().put("integerValue", r.time.toString()))
            .put("cell", str(cell(la, lo)))
        post("${base()}/measurements?key=${Config.API_KEY}", JSONObject().put("fields", fields))
    }

    suspend fun fetchNear(lat: Double, lon: Double): List<CommunityPoint> = withContext(Dispatchers.IO) {
        val cx = floor(lat / CELL).toInt(); val cy = floor(lon / CELL).toInt()
        val values = JSONArray()
        for (dx in -1..1) for (dy in -1..1) values.put(str("${cx + dx}_${cy + dy}"))
        val q = JSONObject().put("structuredQuery", JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", "measurements")))
            .put("where", JSONObject().put("fieldFilter", JSONObject()
                .put("field", JSONObject().put("fieldPath", "cell"))
                .put("op", "IN")
                .put("value", JSONObject().put("arrayValue", JSONObject().put("values", values)))))
            .put("limit", 500))
        val arr = JSONArray(post("${base()}:runQuery?key=${Config.API_KEY}", q))
        val out = mutableListOf<CommunityPoint>()
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i).optJSONObject("document")?.optJSONObject("fields") ?: continue
            try {
                fun s(k: String) = f.getJSONObject(k).getString("stringValue")
                fun d(k: String): Double = f.getJSONObject(k).let {
                    if (it.has("doubleValue")) it.getDouble("doubleValue") else it.getString("integerValue").toDouble()
                }
                out += CommunityPoint(s("operator"), s("connection"), d("down"), d("up"), d("ping"),
                    d("lat"), d("lon"), d("time").toLong())
            } catch (e: Exception) { /* skip malformed document */ }
        }
        out
    }
}
